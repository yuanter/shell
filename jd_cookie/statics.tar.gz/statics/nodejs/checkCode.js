
const jdLib = require('./sms_login_encode.js');



const args = process.argv.splice(2)




!(async() => {
	//调用获取ck
	const phone_args0 = args[0]
	const code_args1 = args[1]
	var phone = phone_args0.split("=")[1];
	var code = code_args1.split("=")[1];
	var gsalt = args[2].split("=")[1];
	var guid = args[3].split("=")[1];
	var lsid = args[4].split("=")[1];
    const res = await checkCode({
      gsalt: gsalt,
      guid: guid,
      lsid: lsid,
      mobile: phone,
      smscode: code,
    });
	
    if (res.err_code != 0) {
      var ret = 
		  {
			ok: false,
			msg: '获取ck失败',
			data: {
			  ck: "",
			},
		  }
		console.log(ret);
    } else {
		const cookie =
        'pt_key=' +
        res.data.pt_key +
        ';pt_pin=' +
        encodeURIComponent(res.data.pt_pin) +
        ';';
		var ret = 
		  {
			ok: true,
			msg: '获取ck成功',
			data: {
			  ck: cookie,
			},
		  }
		console.log(ret);
		 
	
    }
})()
.catch((e) => {
	console.log('', `❌失败! 原因: ${e}!`, '')
})
.finally(() => {
	process.exit()
})


async function checkCode(data) {
  const res = await jdLib.doTelLogin(data);
  return res;
}




